#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from websocket_server import WebsocketServer
import qi
import json
import os
from  threading import Thread




class WebsocketService():
    def __init__(self, session):
        self.session = session
        self.appRootPath = '/home/nao/.local/share/PackageManager/apps/'
        self.memory = None

    def run(self):
        PORT = 9001
        self.server = WebsocketServer(PORT, "198.18.0.1")
        self.server.set_fn_new_client(self.new_client)
        self.server.set_fn_client_left(self.client_left)
        self.server.set_fn_message_received(self.message_received)
        self.server.set_fn_ping_received(self.ping_received)
        self.server.run_forever()

    def creatSignal(self):
        self.memory = self.session.service("ALMemory")
        self.memory.declareEvent("PowerRobot/PushResult")

        self.subPushResult = self.memory.subscriber("PowerRobot/PushResult")
        
        self.subPushResult.signal.connect(self.pushResult)

    def startWebsocketServer(self):
        #t1 = Thread(target=self.run)
        #t1.start()
        PORT = 9001
        self.server = WebsocketServer(PORT, "198.18.0.1")
        self.server.set_fn_new_client(self.new_client)
        self.server.set_fn_client_left(self.client_left)
        self.server.set_fn_message_received(self.message_received)
        self.server.set_fn_ping_received(self.ping_received)
        self.server.run_forever()

    # Called for every client connecting (after handshake)
    def new_client(self, client, server):
        print("New client connected and was given id %d" % client['id'])
        self.client = client["handler"]

    def ping_received(self, client, server, msg):
        print "ping received"
        self.client.send_pong("a");
        
    def client_left(self, client, server):
        print("Client(%d) disconnected" % client['id'])

    # Called when a client sends a message
    def message_received(self, client, server, message):
       
        if len(message) > 0:
            try:
                request = json.loads(message)
                app = request['app']
                service = request['service']
                method = request['command']
                parametersTemp = request['parameters']
                
                parameters = json.loads(parametersTemp)
                
                typeMessage = True
            except Exception as e:
                ret = {"eventId":"101", "eventType":"FormatError"}
                self.client.send_text(json.dumps(ret))
                typeMessage = False
                return
                

            self.commandFromClient(service, method, parameters)

        print("Client(%d) said: %s" % (client['id'], message))    

    def pushResult(self, event):
        callBackValue = json.loads(event)
        eventType = callBackValue["eventType"]
        valueType = callBackValue["valueType"]
        valueResult = callBackValue["valueResult"]

        eventValue = {"type":valueType, "result":valueResult}

        ret = {"eventId":"101", "eventType":eventType, "eventValue":json.dumps(eventValue)}
        print("ret", ret)
        self.client.send_text(json.dumps(ret))

    def commandFromClient(self, service, method, parameters):
        
        try:
            serviceInstance = self.session.service(service)
        except Exception as e:
            print "there is no {} service".format(service)

        try:
            serviceInstance.call(method, parameters)
        except Exception as e:
            print "there is no {} method".format(method)

    def cleanup(self):
        try:
            print "cleanup"
            self.memory.removeData("PowerRobot/PushResult")
        except Exception as e:
            print(e)
        


if __name__ == '__main__':
    app = qi.Application()
    app.start()

    websocketServiceInstance = WebsocketService(app.session)
    serviceId =  app.session.registerService("WebsocketService", websocketServiceInstance)
    websocketServiceInstance.creatSignal()
    websocketServiceInstance.startWebsocketServer()
    
    app.run()
    
    websocketServiceInstance.cleanup()
    app.session.unregisterService(serviceId)
    

