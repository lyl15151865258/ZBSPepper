#!/bin/bash

serviceName=$1
serviceScript=$2
logRoot=/var/log/transam/

if test -z ${serviceName}; then
    echo "Please input serviceName"
    exit 1
fi

if test -z ${serviceScript}; then
    echo "Please input serviceScript"
    exit 1
fi

if !(test -d ${logRoot}); then
    mkdir ${logRoot}
fi

pids=$(ps -ef |grep python| grep ${serviceName} | grep -v grep | awk '{print $2}')

for pid in ${pids}
do
	kill -9 ${pid}
done

nohup python $serviceScript 1>${logRoot}${serviceName}.log 2>${logRoot}${serviceName}_error.log &