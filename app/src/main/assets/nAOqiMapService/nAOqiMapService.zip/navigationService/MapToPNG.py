#! /usr/bin/env python
# -*- encoding: UTF-8 -*-

"""Example: Use localization methods"""

import qi
import argparse
import sys
import numpy
import cv2
import base64
import warnings

def main(session, exploration_file, path):
    """
    This example uses localization methods.
    """
    # Get the services ALNavigation and ALMotion.
    navigation_service = session.service("ALNavigation")
    motion_service = session.service("ALMotion")

    # Wake up robot
    motion_service.wakeUp()

    navigation_service.stopExploration()
    # Load a previously saved exploration
    ismap = navigation_service.loadExploration(exploration_file)
    print str(ismap)

    result_map = navigation_service.getMetricalMap();
    map_width = result_map[1]
    #print "map_width" + str(map_width)
    map_height = result_map[2]
    #print "map_height" +  str(map_height)
    map_data = result_map[4]
    #print "map_data" + str(map_data)

    img = numpy.array(map_data, numpy.uint8).reshape(map_width, map_height, 1)
    img = (100 - img) * 2.25

    img = img.transpose((1, 0, 2))

    #png
    flag, buff = cv2.imencode(".png", img)

    # base 64
    buffer64 = base64.b64encode(buff)
    full = "data:image/png;base64," + buffer64

    with open(path, "wb") as f:
        f.write(base64.b64decode(buffer64))

if __name__ == "__main__":
    warnings.filterwarnings(action="ignore", category=UserWarning, module='qi')
    parser = argparse.ArgumentParser()
    parser.add_argument("--ip", type=str, default="127.0.0.1",
                        help="Robot IP address. On robot or Local Naoqi: use '127.0.0.1'.")
    parser.add_argument("--port", type=int, default=9559,
                        help="Naoqi port number")
    parser.add_argument("--explo", type=str, help="Path to .explo file.")

    parser.add_argument("--outputFilePath", type=str, default="./", help="a path to save map")
    args = parser.parse_args()
    session = qi.Session()
    try:
        session.connect("tcp://" + args.ip + ":" + str(args.port))
    except RuntimeError:
        print ("Can't connect to Naoqi at ip \"" + args.ip + "\" on port " + str(args.port) +".\n"
               "Please check your script arguments. Run with -h option for help.")
        sys.exit(1)
    main(session, args.explo, args.outputFilePath)
